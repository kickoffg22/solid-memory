function Exercise3_nubs(gesture_l,gesture_o,gesture_x,k)
cluster_l = nubs(gesture_l,k);
cluster_o = nubs(gesture_o,k);
cluster_x = nubs(gesture_x,k);

cluster_plot(cluster_l,'gesture l,nubs')
cluster_plot(cluster_o,'gesture o,nubs')
cluster_plot(cluster_x,'gesture x,nubs')

end