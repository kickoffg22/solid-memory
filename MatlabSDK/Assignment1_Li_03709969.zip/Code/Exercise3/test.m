load('gesture_dataset.mat')
Exercise3_kmeans(gesture_l,gesture_o,gesture_x,init_cluster_l,init_cluster_o,init_cluster_x,7)
Exercise3_nubs(gesture_l,gesture_o,gesture_x,7)