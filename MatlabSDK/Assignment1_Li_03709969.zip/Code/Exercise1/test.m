par_2 = Exercise1(2);
par_5 = Exercise1(5);

Simulate_robot(0,0.05);
Simulate_robot(1,0);
Simulate_robot(1,0.05);
Simulate_robot(-1,-0.05);